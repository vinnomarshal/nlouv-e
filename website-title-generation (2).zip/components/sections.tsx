"use client"

import { useState, useEffect } from "react"
import { Menu, X, Search, User, ShoppingBag, ChevronRight, ChevronDown, Instagram, Heart } from "lucide-react"
import Link from "next/link"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const shopCategories = [
    { name: "T-Shirts", href: "#", image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_105919_ibisPaint%20X-TVbwbZNAJTfTsZHJFVN2FNsfTABO8I.jpg" },
    { name: "Hoodies", href: "#", image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260522_122656_509-RlCDlOdwzNLQZ7mjxs0wSJEUWCC3NO.webp" },
    { name: "Shirts", href: "#", image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/d23b416fb9dd2703b622a2938de6e754-cAv6sIF9p0ir4bEvjJGheMplG3UD3y.jpg" },
    { name: "Graphic Tees", href: "#", image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_181920_ibisPaint%20X-ilNf2DBqdEuSXYw8FZQ315Ojdxm0Oy.jpg" },
  ]

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-background/95 backdrop-blur-md shadow-sm" : "bg-background"}`}>
      {/* Announcement Bar */}
      <div className="bg-foreground text-background">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center h-9 text-xs tracking-widest">
            <span className="animate-pulse">FREE SHIPPING ON ORDERS OVER RP 500.000</span>
          </div>
        </div>
      </div>
      
      {/* Main Navigation */}
      <nav className="border-b border-border/50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Mobile Menu Button */}
            <button 
              className="lg:hidden p-2 -ml-2 hover:bg-secondary/50 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            {/* Desktop Navigation Left */}
            <div className="hidden lg:flex items-center gap-1">
              {/* Shop Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setActiveDropdown("shop")}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button className="flex items-center gap-1 px-4 py-2 text-xs tracking-widest hover:bg-secondary/50 transition-colors">
                  SHOP
                  <ChevronDown className={`w-3 h-3 transition-transform ${activeDropdown === "shop" ? "rotate-180" : ""}`} />
                </button>
                
                {activeDropdown === "shop" && (
                  <div className="absolute top-full left-0 w-[600px] bg-background border border-border shadow-xl p-6 grid grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-xs tracking-widest text-muted-foreground">CATEGORIES</h4>
                      {shopCategories.map((cat) => (
                        <Link 
                          key={cat.name}
                          href={cat.href}
                          className="flex items-center gap-4 group"
                        >
                          <div className="w-16 h-16 bg-secondary overflow-hidden">
                            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                          </div>
                          <span className="text-sm tracking-wider group-hover:underline underline-offset-4">{cat.name}</span>
                        </Link>
                      ))}
                    </div>
                    <div className="bg-secondary p-4 flex flex-col justify-end">
                      <span className="text-xs tracking-widest text-muted-foreground mb-2">FEATURED</span>
                      <h5 className="text-lg font-serif mb-2">New Arrivals</h5>
                      <p className="text-xs text-muted-foreground mb-4">Check out our latest drops</p>
                      <Link href="#new" className="text-xs tracking-widest underline underline-offset-4">SHOP NOW</Link>
                    </div>
                  </div>
                )}
              </div>

              <Link href="#new" className="px-4 py-2 text-xs tracking-widest hover:bg-secondary/50 transition-colors">
                NEW ARRIVALS
              </Link>
              <Link href="#collections" className="px-4 py-2 text-xs tracking-widest hover:bg-secondary/50 transition-colors">
                COLLECTIONS
              </Link>
            </div>
            
            {/* Logo */}
            <Link href="/" className="absolute left-1/2 -translate-x-1/2 group">
              <div className="relative">
                <h1 className="text-2xl lg:text-3xl font-serif tracking-[0.2em] font-medium group-hover:tracking-[0.25em] transition-all duration-300">
                  NLOUV&apos;E
                </h1>
                <span className="absolute -bottom-1 left-0 right-0 h-px bg-foreground scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
              </div>
            </Link>

            {/* Desktop Navigation Right */}
            <div className="hidden lg:flex items-center gap-1">
              <Link href="#" className="px-4 py-2 text-xs tracking-widest hover:bg-secondary/50 transition-colors">
                LOOKBOOK
              </Link>
              <Link href="#about" className="px-4 py-2 text-xs tracking-widest hover:bg-secondary/50 transition-colors">
                ABOUT
              </Link>
            </div>

            {/* Icons */}
            <div className="flex items-center gap-0">
              <button className="p-3 hover:bg-secondary/50 transition-colors relative group" aria-label="Search">
                <Search className="w-5 h-5" />
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[8px] tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">SEARCH</span>
              </button>
              <button className="p-3 hover:bg-secondary/50 transition-colors relative group hidden sm:flex" aria-label="Account">
                <User className="w-5 h-5" />
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[8px] tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">ACCOUNT</span>
              </button>
              <button className="p-3 hover:bg-secondary/50 transition-colors relative group" aria-label="Shopping bag">
                <ShoppingBag className="w-5 h-5" />
                <span className="absolute -top-0 -right-0 w-4 h-4 bg-foreground text-background text-[10px] flex items-center justify-center">0</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation - Full Screen Overlay */}
        <div className={`lg:hidden fixed inset-0 top-[calc(2.25rem+4rem)] bg-background z-50 transition-all duration-500 ${isMenuOpen ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none"}`}>
          <div className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto py-6">
              <div className="space-y-0">
                <Link 
                  href="#new" 
                  className="flex items-center justify-between px-6 py-5 text-lg tracking-widest border-b border-border/50 hover:bg-secondary/30 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  NEW ARRIVALS
                  <ChevronRight className="w-5 h-5" />
                </Link>
                
                <div className="border-b border-border/50">
                  <div className="px-6 py-5 text-lg tracking-widest flex items-center justify-between">
                    SHOP
                    <ChevronDown className="w-5 h-5" />
                  </div>
                  <div className="pb-4 px-6 space-y-3">
                    {shopCategories.map((cat) => (
                      <Link 
                        key={cat.name}
                        href={cat.href}
                        className="flex items-center gap-4 py-2"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-12 h-12 bg-secondary overflow-hidden">
                          <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                        </div>
                        <span className="text-sm tracking-wider">{cat.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>

                <Link 
                  href="#collections" 
                  className="flex items-center justify-between px-6 py-5 text-lg tracking-widest border-b border-border/50 hover:bg-secondary/30 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  COLLECTIONS
                  <ChevronRight className="w-5 h-5" />
                </Link>
                <Link 
                  href="#" 
                  className="flex items-center justify-between px-6 py-5 text-lg tracking-widest border-b border-border/50 hover:bg-secondary/30 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  LOOKBOOK
                  <ChevronRight className="w-5 h-5" />
                </Link>
                <Link 
                  href="#about" 
                  className="flex items-center justify-between px-6 py-5 text-lg tracking-widest border-b border-border/50 hover:bg-secondary/30 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  ABOUT
                  <ChevronRight className="w-5 h-5" />
                </Link>
              </div>
            </div>

            {/* Mobile Menu Footer */}
            <div className="border-t border-border p-6 space-y-4">
              <div className="flex items-center gap-4">
                <Link href="#" className="flex items-center gap-2 text-sm tracking-wider">
                  <User className="w-4 h-4" /> Account
                </Link>
                <span className="text-muted-foreground">|</span>
                <Link href="#" className="flex items-center gap-2 text-sm tracking-wider">
                  <Heart className="w-4 h-4" /> Wishlist
                </Link>
              </div>
              <div className="flex items-center gap-4">
                <Link href="#" aria-label="Instagram">
                  <Instagram className="w-5 h-5" />
                </Link>
                <span className="text-xs tracking-wider text-muted-foreground">@nlouv&apos;e</span>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
  )
}

export function Hero() {
  return (
    <section className="relative min-h-screen pt-32 lg:pt-36">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-0 min-h-[calc(100vh-8rem)]">
          {/* Left - Image */}
          <div className="relative aspect-[3/4] lg:aspect-auto overflow-hidden bg-foreground flex items-center justify-center">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_181920_ibisPaint%20X-ilNf2DBqdEuSXYw8FZQ315Ojdxm0Oy.jpg"
              alt="NLOUV'E Collection"
              className="w-full h-full object-contain"
            />
          </div>
          
          {/* Right - Content */}
          <div className="flex flex-col justify-center px-6 lg:px-16 py-12 lg:py-0 bg-secondary">
            <span className="text-xs tracking-[0.3em] text-muted-foreground mb-4">#BEYOURSELFWITHNLOUVE</span>
            <h2 className="text-4xl lg:text-6xl font-serif tracking-wide leading-tight mb-6">
              BE YOURSELF<br />WITH NLOUV&apos;E
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 max-w-md">
              Express your authentic self through our streetwear collection. Designed for those who dare to be different.
            </p>
            <Link 
              href="#collections"
              className="inline-flex items-center gap-3 text-sm tracking-widest group"
            >
              SHOP THE COLLECTION
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export function FeaturedBanner() {
  return (
    <section className="py-4">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="relative aspect-[21/9] lg:aspect-[21/7] overflow-hidden bg-foreground">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260522_122656_509-RlCDlOdwzNLQZ7mjxs0wSJEUWCC3NO.webp"
            alt="NLOUV'E Hoodie Campaign"
            className="w-full h-full object-contain"
          />
          <div className="absolute inset-0 bg-foreground/30" />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-primary-foreground text-center px-4">
            <span className="text-xs tracking-[0.3em] mb-3">NLOUVEISTAR</span>
            <h3 className="text-3xl lg:text-5xl font-serif tracking-wide mb-4">SIGNATURE HOODIE</h3>
            <Link 
              href="#"
              className="inline-flex items-center gap-2 text-sm tracking-widest border border-primary-foreground px-6 py-3 hover:bg-primary-foreground hover:text-foreground transition-colors"
            >
              SHOP NOW
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export function NewArrivals() {
  const products = [
    {
      name: "Heavywhite Signature Classic",
      price: "Rp 350.000",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_105919_ibisPaint%20X-TVbwbZNAJTfTsZHJFVN2FNsfTABO8I.jpg",
      category: "T-Shirts",
      tag: "NEW"
    },
    {
      name: "Marshall Authentic Tee",
      price: "Rp 375.000",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/canvas%20%284%29-oc7hq6TRFKo4F4DpsfkimTg60YO6hc.png",
      category: "T-Shirts",
      tag: "NEW"
    },
    {
      name: "NLOUVE X Graphic Tee",
      price: "Rp 425.000",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_181920_ibisPaint%20X-ilNf2DBqdEuSXYw8FZQ315Ojdxm0Oy.jpg",
      category: "T-Shirts",
      tag: "BESTSELLER"
    },
    {
      name: "Nlouve Star Hoodie",
      price: "Rp 650.000",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260522_122656_509-RlCDlOdwzNLQZ7mjxs0wSJEUWCC3NO.webp",
      category: "Hoodies",
      tag: "BESTSELLER"
    },
    {
      name: "Classic Stripe Shirt",
      price: "Rp 450.000",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/d23b416fb9dd2703b622a2938de6e754-cAv6sIF9p0ir4bEvjJGheMplG3UD3y.jpg",
      category: "Shirts",
      tag: "NEW"
    }
  ]

  return (
    <section id="new" className="py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-xs tracking-[0.3em] text-muted-foreground">NEW THIS SEASON</span>
            <h2 className="text-3xl lg:text-4xl font-serif tracking-wide mt-2">NEW ARRIVALS</h2>
          </div>
          <Link 
            href="#"
            className="hidden md:inline-flex items-center gap-2 text-sm tracking-widest hover:underline underline-offset-4"
          >
            VIEW ALL
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
          {products.map((product, index) => (
            <Link key={index} href="#" className="group">
              <div className="relative aspect-square overflow-hidden bg-secondary mb-4">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                {product.tag && (
                  <span className="absolute top-3 left-3 bg-foreground text-background text-[10px] tracking-wider px-2 py-1">
                    {product.tag}
                  </span>
                )}
                <button 
                  className="absolute top-3 right-3 p-2 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label="Add to wishlist"
                >
                  <Heart className="w-4 h-4" />
                </button>
              </div>
              <span className="text-xs tracking-wider text-muted-foreground">{product.category}</span>
              <h3 className="text-sm lg:text-base mt-1 mb-1 group-hover:underline underline-offset-4">{product.name}</h3>
              <p className="text-sm font-medium">{product.price}</p>
            </Link>
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <Link 
            href="#"
            className="inline-flex items-center gap-2 text-sm tracking-widest hover:underline underline-offset-4"
          >
            VIEW ALL PRODUCTS
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  )
}

export function Collections() {
  const collections = [
    {
      title: "T-SHIRTS",
      subtitle: "Essential Basics",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20260521_105919_ibisPaint%20X-TVbwbZNAJTfTsZHJFVN2FNsfTABO8I.jpg"
    },
    {
      title: "HOODIES",
      subtitle: "Signature Streetwear", 
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260522_122656_509-RlCDlOdwzNLQZ7mjxs0wSJEUWCC3NO.webp"
    },
    {
      title: "SHIRTS",
      subtitle: "Classic Collection",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/d23b416fb9dd2703b622a2938de6e754-cAv6sIF9p0ir4bEvjJGheMplG3UD3y.jpg"
    }
  ]

  return (
    <section id="collections" className="py-16 lg:py-24 bg-secondary">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-xs tracking-[0.3em] text-muted-foreground">EXPLORE</span>
          <h2 className="text-3xl lg:text-4xl font-serif tracking-wide mt-2">OUR COLLECTIONS</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-4 lg:gap-6">
          {collections.map((item, index) => (
            <Link key={index} href="#" className="group relative aspect-[3/4] overflow-hidden bg-foreground">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-foreground/40 group-hover:bg-foreground/50 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-primary-foreground">
                <h3 className="text-2xl lg:text-3xl font-serif tracking-wider mb-1">{item.title}</h3>
                <p className="text-xs tracking-widest">{item.subtitle}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

export function Featured() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-0">
          <div className="relative aspect-square lg:aspect-auto overflow-hidden bg-secondary flex items-center justify-center">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/canvas%20%284%29-oc7hq6TRFKo4F4DpsfkimTg60YO6hc.png"
              alt="Marshall Authentic Collection"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="flex flex-col justify-center lg:pl-16 xl:pl-24">
            <span className="text-xs tracking-[0.3em] text-muted-foreground mb-4">MARSHALL AUTHENTIC</span>
            <h2 className="text-3xl lg:text-5xl font-serif tracking-wide leading-tight mb-6">
              n.l.o.u.v.e<br />COLLECTION
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6 max-w-lg">
              The Marshall Authentic line represents the core of NLOUV&apos;E - minimalist designs 
              with maximum impact. Each piece features our signature branding with premium quality materials.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8 max-w-lg">
              Crafted for comfort and style, our oversized tees are perfect for 
              everyday wear while making a statement.
            </p>
            <Link 
              href="#"
              className="inline-flex items-center gap-3 text-sm tracking-widest group w-fit"
            >
              EXPLORE THE COLLECTION
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export function About() {
  return (
    <section id="about" className="py-16 lg:py-24 bg-foreground text-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-xs tracking-[0.3em] text-background/60">THE BRAND</span>
          <h2 className="text-3xl lg:text-5xl font-serif tracking-wide mt-4 mb-8">NLOUV&apos;E</h2>
          <p className="text-background/80 leading-relaxed mb-8 text-lg">
            NLOUV&apos;E is more than just clothing - it&apos;s a statement of individuality. 
            Born from the streets, crafted for those who dare to express themselves authentically.
          </p>
          <p className="text-background/80 leading-relaxed mb-12">
            #BEYOURSELFWITHNLOUVE - Our philosophy is simple: wear what makes you feel powerful. 
            Each piece is designed to help you stand out while staying true to who you are.
          </p>
          
          <div className="grid grid-cols-3 gap-8 pt-8 border-t border-background/20">
            <div>
              <span className="text-4xl lg:text-5xl font-serif">25+</span>
              <p className="mt-2 text-xs tracking-widest text-background/60">DESIGNS</p>
            </div>
            <div>
              <span className="text-4xl lg:text-5xl font-serif">100%</span>
              <p className="mt-2 text-xs tracking-widest text-background/60">ORIGINAL</p>
            </div>
            <div>
              <span className="text-4xl lg:text-5xl font-serif">ID</span>
              <p className="mt-2 text-xs tracking-widest text-background/60">BASED</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export function Newsletter() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <span className="text-xs tracking-[0.3em] text-muted-foreground">STAY CONNECTED</span>
          <h2 className="text-3xl lg:text-4xl font-serif tracking-wide mt-4 mb-4">
            JOIN THE NLOUV&apos;E COMMUNITY
          </h2>
          <p className="text-muted-foreground mb-8">
            Be the first to know about new drops, exclusive releases, and special offers.
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Enter your email address"
              className="flex-1 px-4 py-3 bg-transparent border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:border-foreground transition-colors"
            />
            <button 
              type="submit"
              className="px-8 py-3 bg-foreground text-background text-sm tracking-widest hover:bg-foreground/90 transition-colors"
            >
              SUBSCRIBE
            </button>
          </form>
          <p className="text-xs text-muted-foreground mt-4">
            By subscribing, you agree to our Privacy Policy.
          </p>
        </div>
      </div>
    </section>
  )
}

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Main Footer */}
        <div className="py-12 lg:py-16 grid grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="col-span-2 lg:col-span-1">
            <Link href="/" className="text-xl font-serif tracking-[0.3em]">
              NLOUV&apos;E
            </Link>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Be Yourself With NLOUV&apos;E
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              @nlouv&apos;e
            </p>
          </div>
          
          <div>
            <h4 className="text-xs tracking-widest mb-4">SHOP</h4>
            <div className="flex flex-col gap-3">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                New Arrivals
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                T-Shirts
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Hoodies
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Shirts
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Bestsellers
              </Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs tracking-widest mb-4">HELP</h4>
            <div className="flex flex-col gap-3">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Size Guide
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Shipping & Delivery
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Returns & Exchanges
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Contact Us
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                FAQ
              </Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs tracking-widest mb-4">THE BRAND</h4>
            <div className="flex flex-col gap-3">
              <Link href="#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                About Us
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Lookbook
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Stores
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Careers
              </Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs tracking-widest mb-4">FOLLOW US</h4>
            <div className="flex items-center gap-4">
              <Link href="#" className="hover:text-muted-foreground transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </Link>
              <Link href="#" className="hover:text-muted-foreground transition-colors" aria-label="TikTok">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </Link>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              #BEYOURSELFWITHNLOUVE
            </p>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="py-6 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; 2024 NLOUV&apos;E. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
