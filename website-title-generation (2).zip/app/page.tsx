import { Header, Hero, FeaturedBanner, NewArrivals, Collections, Featured, About, Newsletter, Footer } from "@/components/sections"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <FeaturedBanner />
      <NewArrivals />
      <Collections />
      <Featured />
      <About />
      <Newsletter />
      <Footer />
    </main>
  )
}
